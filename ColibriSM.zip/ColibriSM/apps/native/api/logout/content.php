<?php 
# @*************************************************************************@
# @ Software author: Mansur Altamirov (Mansur_TL)                           @
# @ Author_url 1: https://www.instagram.com/mansur_tl                       @
# @ Author_url 2: http://codecanyon.net/user/mansur_tl                      @
# @ Author E-mail: vayart.help@gmail.com                                    @
# @*************************************************************************@
# @ ColibriSM - The Ultimate Modern Social Media Sharing Platform           @
# @ Copyright (c) 2020 - 2021 ColibriSM. All rights reserved.               @
# @*************************************************************************@

if (empty($cl['is_logged'])) {
	$data         = array(
		'code'    => 401,
		'data'    => array(),
		'message' => 'Unauthorized Access'
	);
}
else {
	cl_db_delete_item(T_SESSIONS, array(
		"user_id"  => $me["id"],
		"platform" => "mobile_ios"
	));

	cl_db_delete_item(T_SESSIONS, array(
		"user_id"  => $me["id"],
		"platform" => "mobile_android"
	));

	$data         = array(
		'valid'   => true,
		'code'    => 200,
		'message' => 'Signout successful',
		'data'    => array()
	);
}