# makeup

```php
makeup ( ) : string
```

Returns the HTML representation of the current node.